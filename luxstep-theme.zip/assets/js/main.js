document.querySelectorAll(".add-cart").forEach(btn=>{
btn.onclick=()=>{
alert("تمت إضافة المنتج للسلة");
}
})